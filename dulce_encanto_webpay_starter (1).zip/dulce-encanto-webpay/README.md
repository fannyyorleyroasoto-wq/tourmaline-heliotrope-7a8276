# Dulce Encanto — tienda con Webpay Plus

Tienda web responsive con catálogo, carrito, selección de despacho a domicilio o retiro, y redirección a la pasarela oficial Webpay Plus. El servidor calcula los precios a partir de un catálogo fijo y confirma el resultado consultando Transbank. El navegador nunca solicita ni guarda datos de tarjeta.

## Probar localmente
1. Instala Node.js 18 o superior.
2. En esta carpeta ejecuta `npm install`.
3. Copia `.env.example` a `.env` y revisa las variables.
4. Ejecuta `npm start` y abre `http://localhost:3000`.

Por defecto el SDK usa ambiente de integración de Transbank. No se cobra dinero real en integración.

## Publicar en Render
1. Descomprime el ZIP y sube **el contenido de la carpeta**, no solamente el ZIP, al repositorio GitHub.
2. En Render crea un servicio **Web Service** conectado a ese repositorio.
3. Build Command: `npm install`
4. Start Command: `npm start`
5. En Environment agrega `BASE_URL` con la URL HTTPS que Render asigne, `USE_INTEGRATION=true`, `WHATSAPP_NUMBER=56936672794`. En integración puedes omitir las credenciales porque el SDK usa credenciales de prueba por defecto. Nunca publiques una API key real en GitHub.
6. Prueba todo el flujo en integración con tarjetas de prueba oficiales de Transbank.
7. Para producción, primero contrata/activa Webpay Plus y configura `USE_INTEGRATION=false`, `TRANSBANK_COMMERCE_CODE` y `TRANSBANK_API_KEY` con los valores privados entregados por Transbank. No actives producción hasta validar retorno, confirmación, cancelación y pedidos.

## Importante antes de vender
- Esta versión guarda órdenes pendientes solo en memoria; al reiniciar el servicio se pierden. Antes de operar comercialmente, conectar una base de datos persistente para órdenes, idempotencia, inventario y seguimiento.
- Configurar en Transbank la URL HTTPS pública de retorno y completar sus pruebas/validación.
- El catálogo, precios y costo de envío son datos de demostración y deben revisarse.
- Las credenciales reales deben guardarse únicamente en variables de entorno de Render, nunca en el HTML ni en el repositorio.
